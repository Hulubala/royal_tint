// ✅ CORRECT VERSION - TIME SLOT CALENDAR 9AM-7PM
// This is what you originally had! Grid view + Time availability slots

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:bootstrap_icons/bootstrap_icons.dart';
import 'package:royal_tint/features/manager/providers/manager_provider.dart';
import 'package:royal_tint/features/auth/providers/auth_provider.dart';
import 'package:royal_tint/data/models/appointment_model.dart';
import 'package:royal_tint/data/models/tint_package_model.dart';
import 'package:royal_tint/services/appointment_service.dart';
import 'package:royal_tint/services/package_service.dart';
import 'package:intl/intl.dart';

// Vehicle Database
class VehicleDatabase {
  static const Map<String, List<String>> brandModels = {
    'Perodua': ['Myvi', 'Axia', 'Bezza', 'Aruz', 'Alza'],
    'Proton': ['Saga', 'Persona', 'Iriz', 'X50', 'X70', 'Exora'],
    'Honda': ['Civic', 'City', 'Accord', 'CR-V', 'HR-V', 'BR-V'],
    'Toyota': ['Vios', 'Camry', 'Corolla', 'Fortuner', 'Rush', 'Innova', 'Alphard'],
    'Nissan': ['Almera', 'Teana', 'X-Trail', 'Serena'],
    'Mazda': ['2', '3', '6', 'CX-3', 'CX-5'],
    'Mercedes': ['C-Class', 'E-Class', 'GLC'],
    'BMW': ['3 Series', '5 Series', 'X3', 'X5'],
  };

  static const Map<String, Map<String, String>> modelDetails = {
    'Myvi': {'type': 'Sedan', 'minutes': '90'},
    'Axia': {'type': 'Sedan', 'minutes': '90'},
    'Bezza': {'type': 'Sedan', 'minutes': '90'},
    'Aruz': {'type': 'SUV', 'minutes': '120'},
    'Alza': {'type': 'MPV', 'minutes': '120'},
    'Saga': {'type': 'Sedan', 'minutes': '90'},
    'Persona': {'type': 'Sedan', 'minutes': '90'},
    'Iriz': {'type': 'Sedan', 'minutes': '90'},
    'X50': {'type': 'SUV', 'minutes': '120'},
    'X70': {'type': 'SUV', 'minutes': '120'},
    'Exora': {'type': 'MPV', 'minutes': '120'},
    'Civic': {'type': 'Sedan', 'minutes': '90'},
    'City': {'type': 'Sedan', 'minutes': '90'},
    'Accord': {'type': 'Sedan', 'minutes': '90'},
    'CR-V': {'type': 'SUV', 'minutes': '120'},
    'HR-V': {'type': 'SUV', 'minutes': '120'},
    'BR-V': {'type': 'MPV', 'minutes': '120'},
    'Vios': {'type': 'Sedan', 'minutes': '90'},
    'Camry': {'type': 'Sedan', 'minutes': '90'},
    'Corolla': {'type': 'Sedan', 'minutes': '90'},
    'Fortuner': {'type': 'SUV', 'minutes': '120'},
    'Rush': {'type': 'SUV', 'minutes': '120'},
    'Innova': {'type': 'MPV', 'minutes': '120'},
    'Alphard': {'type': 'MPV', 'minutes': '120'},
    'Almera': {'type': 'Sedan', 'minutes': '90'},
    'Teana': {'type': 'Sedan', 'minutes': '90'},
    'X-Trail': {'type': 'SUV', 'minutes': '120'},
    'Serena': {'type': 'MPV', 'minutes': '120'},
    '2': {'type': 'Sedan', 'minutes': '90'},
    '3': {'type': 'Sedan', 'minutes': '90'},
    '6': {'type': 'Sedan', 'minutes': '90'},
    'CX-3': {'type': 'SUV', 'minutes': '120'},
    'CX-5': {'type': 'SUV', 'minutes': '120'},
    'C-Class': {'type': 'Sedan', 'minutes': '90'},
    'E-Class': {'type': 'Sedan', 'minutes': '90'},
    'GLC': {'type': 'SUV', 'minutes': '120'},
    '3 Series': {'type': 'Sedan', 'minutes': '90'},
    '5 Series': {'type': 'Sedan', 'minutes': '90'},
    'X3': {'type': 'SUV', 'minutes': '120'},
    'X5': {'type': 'SUV', 'minutes': '120'},
  };

  static List<String> getAllBrands() => brandModels.keys.toList()..sort();
  static List<String> getModelsByBrand(String brand) => brandModels[brand] ?? [];
  static String getType(String model) => modelDetails[model]?['type'] ?? 'Sedan';
  static int getMinutes(String model) => int.parse(modelDetails[model]?['minutes'] ?? '90');
}

class AppointmentManagementScreen extends StatefulWidget {
  const AppointmentManagementScreen({super.key});

  @override
  State<AppointmentManagementScreen> createState() => _AppointmentManagementScreenState();
}

class _AppointmentManagementScreenState extends State<AppointmentManagementScreen> {
  bool _isInitialized = false;
  String _selectedType = 'all';
  String _selectedStatus = 'all';
  String _searchQuery = '';
  String _dateFilter = 'all';
  DateTime? _customDate;
  
  // 📅 CALENDAR VIEW STATE
  bool _showCalendarView = false;
  DateTime _selectedCalendarDate = DateTime.now();

  @override
  void initState() {
    super.initState();
    _initializeData();
  }

  Future<void> _initializeData() async {
    if (_isInitialized) return;
    await Future.delayed(Duration.zero);
    final authProvider = context.read<AuthProvider>();
    final managerProvider = context.read<ManagerProvider>();
    if (authProvider.branchID != null) {
      await managerProvider.fetchAppointments(authProvider.branchID!);
    }
    setState(() => _isInitialized = true);
  }

  List<AppointmentModel> _getFilteredAppointments(List<AppointmentModel> appointments) {
    return appointments.where((apt) {
      if (_selectedStatus != 'all' && apt.status.toLowerCase() != _selectedStatus) return false;
      if (_searchQuery.isNotEmpty) {
        final query = _searchQuery.toLowerCase();
        if (!apt.customerName.toLowerCase().contains(query) &&
            !apt.vehiclePlate.toLowerCase().contains(query) &&
            !apt.vehicleModel.toLowerCase().contains(query) &&
            !(apt.customerPhone?.toLowerCase().contains(query) ?? false)) return false;
      }
      if (_dateFilter != 'all') {
        final aptDate = DateTime.parse(apt.appointmentDate);
        final now = DateTime.now();
        switch (_dateFilter) {
          case 'today': if (!_isSameDay(aptDate, now)) return false; break;
          case 'tomorrow': if (!_isSameDay(aptDate, now.add(const Duration(days: 1)))) return false; break;
          case 'week': if (aptDate.isBefore(now) || aptDate.isAfter(now.add(const Duration(days: 7)))) return false; break;
          case 'month': if (aptDate.month != now.month || aptDate.year != now.year) return false; break;
          case 'custom': if (_customDate != null && !_isSameDay(aptDate, _customDate!)) return false; break;
        }
      }
      return true;
    }).toList();
  }

  bool _isSameDay(DateTime a, DateTime b) => a.year == b.year && a.month == b.month && a.day == b.day;

  Map<String, int> _getStatistics(List<AppointmentModel> appointments) {
    return {
      'total': appointments.length,
      'pending': appointments.where((a) => a.status.toLowerCase() == 'pending').length,
      'confirmed': appointments.where((a) => a.status.toLowerCase() == 'confirmed').length,
      'in-progress': appointments.where((a) => a.status.toLowerCase() == 'in-progress').length,
      'completed': appointments.where((a) => a.status.toLowerCase() == 'completed').length,
      'cancelled': appointments.where((a) => a.status.toLowerCase() == 'cancelled').length,
    };
  }

  void _resetFilters() => setState(() {
    _selectedType = 'all';
    _selectedStatus = 'all';
    _searchQuery = '';
    _dateFilter = 'all';
    _customDate = null;
  });

  Color _getStatusColor(String status) {
    switch (status.toLowerCase()) {
      case 'pending': return const Color(0xFFFFC107);
      case 'confirmed': return const Color(0xFF4CAF50);
      case 'in-progress': return const Color(0xFF2196F3);
      case 'completed': return const Color(0xFF9E9E9E);
      case 'cancelled': return const Color(0xFFF44336);
      default: return Colors.grey;
    }
  }

  IconData _getStatusIcon(String status) {
    switch (status.toLowerCase()) {
      case 'pending': return BootstrapIcons.clock;
      case 'confirmed': return BootstrapIcons.check_circle;
      case 'completed': return BootstrapIcons.check_all;
      case 'cancelled': return BootstrapIcons.x_circle;
      default: return BootstrapIcons.circle;
    }
  }

  Color _getCardBorderColor(int index) {
    final colors = [
      const Color(0xFFFFD700),
      const Color(0xFFFFC107),
      const Color(0xFF00BCD4),
      const Color(0xFF9C27B0),
    ];
    return colors[index % colors.length];
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: const Color(0xFFF5F5F5),
      child: Consumer<ManagerProvider>(
        builder: (context, managerProvider, child) {
          if (!_isInitialized || managerProvider.isLoading) {
            return const Center(child: CircularProgressIndicator(valueColor: AlwaysStoppedAnimation<Color>(Color(0xFFFFD700))));
          }

          if (managerProvider.errorMessage != null) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(BootstrapIcons.exclamation_triangle, color: Colors.red, size: 48),
                  const SizedBox(height: 16),
                  Text('Error: ${managerProvider.errorMessage}', style: const TextStyle(color: Colors.red)),
                  const SizedBox(height: 16),
                  ElevatedButton(onPressed: _initializeData, child: const Text('Retry')),
                ],
              ),
            );
          }

          final filteredAppointments = _getFilteredAppointments(managerProvider.appointments);
          final stats = _getStatistics(managerProvider.appointments);

          return SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildPageHeader(),
                const SizedBox(height: 24),
                _buildViewToggle(),
                const SizedBox(height: 24),
                if (!_showCalendarView) ...[
                  _buildStatsCards(stats),
                  const SizedBox(height: 24),
                  _buildFilterSection(),
                  const SizedBox(height: 24),
                  _buildStatusTabs(stats),
                  const SizedBox(height: 24),
                  _buildAppointmentsGrid(filteredAppointments),
                ] else ...[
                  _buildCalendarView(managerProvider.appointments),
                ],
              ],
            ),
          );
        },
      ),
    );
  }

  // 📅 VIEW TOGGLE
  Widget _buildViewToggle() {
    return Container(
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [Color(0xFF1A1A1A), Colors.black]),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFFFD700), width: 2),
      ),
      child: Row(
        children: [
          Expanded(
            child: InkWell(
              onTap: () => setState(() => _showCalendarView = false),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                decoration: BoxDecoration(
                  gradient: !_showCalendarView ? const LinearGradient(colors: [Color(0xFFFFD700), Color(0xFFFFC700)]) : null,
                  color: !_showCalendarView ? null : Colors.black,
                  border: Border.all(color: const Color(0xFFFFD700), width: 2),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(BootstrapIcons.grid_3x3_gap_fill, color: !_showCalendarView ? Colors.black : const Color(0xFFFFD700), size: 18),
                    const SizedBox(width: 8),
                    Text('Grid View', style: TextStyle(color: !_showCalendarView ? Colors.black : const Color(0xFFFFD700), fontWeight: FontWeight.bold, fontSize: 14)),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: InkWell(
              onTap: () => setState(() => _showCalendarView = true),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                decoration: BoxDecoration(
                  gradient: _showCalendarView ? const LinearGradient(colors: [Color(0xFFFFD700), Color(0xFFFFC700)]) : null,
                  color: _showCalendarView ? null : Colors.black,
                  border: Border.all(color: const Color(0xFFFFD700), width: 2),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(BootstrapIcons.calendar3, color: _showCalendarView ? Colors.black : const Color(0xFFFFD700), size: 18),
                    const SizedBox(width: 8),
                    Text('Calendar View', style: TextStyle(color: _showCalendarView ? Colors.black : const Color(0xFFFFD700), fontWeight: FontWeight.bold, fontSize: 14)),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // 📅 CALENDAR VIEW WITH TIME SLOTS (9AM-7PM)
  Widget _buildCalendarView(List<AppointmentModel> appointments) {
    final dayAppointments = appointments.where((apt) => _isSameDay(DateTime.parse(apt.appointmentDate), _selectedCalendarDate)).toList();
    
    return Column(
      children: [
        // Calendar Date Selector
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [Color(0xFF1A1A1A), Colors.black]),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: const Color(0xFFFFD700), width: 2),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              IconButton(
                onPressed: () => setState(() => _selectedCalendarDate = _selectedCalendarDate.subtract(const Duration(days: 1))),
                icon: const Icon(BootstrapIcons.chevron_left, color: Color(0xFFFFD700)),
              ),
              InkWell(
                onTap: _selectCalendarDate,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(colors: [Color(0xFFFFD700), Color(0xFFFFC700)]),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Row(
                    children: [
                      const Icon(BootstrapIcons.calendar3, color: Colors.black),
                      const SizedBox(width: 12),
                      Text(
                        DateFormat('EEEE, MMMM d, yyyy').format(_selectedCalendarDate),
                        style: const TextStyle(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 16),
                      ),
                    ],
                  ),
                ),
              ),
              IconButton(
                onPressed: () => setState(() => _selectedCalendarDate = _selectedCalendarDate.add(const Duration(days: 1))),
                icon: const Icon(BootstrapIcons.chevron_right, color: Color(0xFFFFD700)),
              ),
            ],
          ),
        ),
        
        const SizedBox(height: 24),
        
        // Time Slots (9AM-7PM)
        _buildTimeSlots(dayAppointments),
      ],
    );
  }

  Future<void> _selectCalendarDate() async {
    final date = await showDatePicker(
      context: context,
      initialDate: _selectedCalendarDate,
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 365)),
      builder: (context, child) => Theme(
        data: ThemeData.dark().copyWith(
          colorScheme: const ColorScheme.dark(primary: Color(0xFFFFD700), onPrimary: Colors.black, surface: Color(0xFF1A1A1A), onSurface: Color(0xFFFFD700)),
        ),
        child: child!,
      ),
    );
    if (date != null) setState(() => _selectedCalendarDate = date);
  }

  // ⏰ TIME SLOTS 9AM-7PM
  Widget _buildTimeSlots(List<AppointmentModel> appointments) {
    return Container(
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [Color(0xFF1A1A1A), Colors.black]),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFFFD700), width: 2),
      ),
      child: Column(
        children: [
          // Header
          Container(
            padding: const EdgeInsets.all(16),
            decoration: const BoxDecoration(
              gradient: LinearGradient(colors: [Colors.black, Color(0xFF1A1A1A)]),
              borderRadius: BorderRadius.only(topLeft: Radius.circular(10), topRight: Radius.circular(10)),
              border: Border(bottom: BorderSide(color: Color(0xFFFFD700), width: 2)),
            ),
            child: const Row(
              children: [
                Icon(BootstrapIcons.clock, color: Color(0xFFFFD700)),
                SizedBox(width: 12),
                Text('AVAILABLE TIME SLOTS', style: TextStyle(color: Color(0xFFFFD700), fontWeight: FontWeight.bold, fontSize: 16)),
              ],
            ),
          ),
          
          // Time slot list (9AM-7PM = 11 slots)
          ListView.separated(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: 11,
            separatorBuilder: (_, __) => Divider(color: const Color(0xFFFFD700).withOpacity(0.2), height: 1),
            itemBuilder: (context, index) {
              final hour = 9 + index;
              final timeSlot = '${hour.toString().padLeft(2, '0')}:00';
              
              // Convert to 12-hour format
              final displayHour = hour > 12 ? hour - 12 : hour;
              final period = hour >= 12 ? 'PM' : 'AM';
              final displayTime = '$displayHour:00 $period';
              
              // Find appointment for this time slot
              AppointmentModel? slotAppointment;
              try {
                slotAppointment = appointments.firstWhere(
                  (a) => a.appointmentTime.startsWith(timeSlot),
                );
              } catch (e) {
                // No appointment for this slot
                slotAppointment = null;
              }
              
              final isFree = slotAppointment == null;

              return Container(
                padding: const EdgeInsets.all(16),
                color: isFree ? null : _getStatusColor(slotAppointment.status).withOpacity(0.1),
                child: Row(
                  children: [
                    // Time Display
                    Container(
                      width: 100,
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.black,
                        border: Border.all(color: const Color(0xFFFFD700), width: 2),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        displayTime,
                        style: const TextStyle(color: Color(0xFFFFD700), fontWeight: FontWeight.bold, fontSize: 14),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    const SizedBox(width: 16),
                    
                    // Slot Status
                    Expanded(
                      child: isFree
                          ? Container(
                              padding: const EdgeInsets.all(16),
                              decoration: BoxDecoration(
                                color: Colors.black,
                                border: Border.all(color: const Color(0xFF4CAF50).withOpacity(0.3), width: 2),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: const Row(
                                children: [
                                  Icon(BootstrapIcons.check_circle, color: Color(0xFF4CAF50), size: 20),
                                  SizedBox(width: 12),
                                  Text('Available', style: TextStyle(color: Color(0xFF4CAF50), fontWeight: FontWeight.bold)),
                                ],
                              ),
                            )
                          : Container(
                              padding: const EdgeInsets.all(16),
                              decoration: BoxDecoration(
                                gradient: LinearGradient(colors: [_getStatusColor(slotAppointment.status).withOpacity(0.2), Colors.black]),
                                border: Border.all(color: _getStatusColor(slotAppointment.status), width: 2),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Row(
                                children: [
                                  Icon(_getStatusIcon(slotAppointment.status), color: _getStatusColor(slotAppointment.status), size: 20),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(slotAppointment.customerName, style: const TextStyle(color: Color(0xFFFFD700), fontWeight: FontWeight.bold, fontSize: 14), overflow: TextOverflow.ellipsis),
                                        const SizedBox(height: 4),
                                        Text('${slotAppointment.vehiclePlate} • ${slotAppointment.packageName}', style: TextStyle(color: const Color(0xFFFFD700).withOpacity(0.7), fontSize: 12), overflow: TextOverflow.ellipsis),
                                      ],
                                    ),
                                  ),
                                  const SizedBox(width: 12),
                                  Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                                    decoration: BoxDecoration(color: _getStatusColor(slotAppointment.status), borderRadius: BorderRadius.circular(12)),
                                    child: Text(slotAppointment.status.toUpperCase(), style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold)),
                                  ),
                                ],
                              ),
                            ),
                    ),
                  ],
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildPageHeader() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [Colors.black, Color(0xFF1A1A1A), Colors.black]),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFFFD700), width: 2),
        boxShadow: [BoxShadow(color: const Color(0xFFFFD700).withOpacity(0.2), blurRadius: 16, offset: const Offset(0, 4))],
      ),
      child: Row(
        children: [
          const Icon(BootstrapIcons.calendar_check, color: Color(0xFFFFD700), size: 28),
          const SizedBox(width: 12),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Appointment Management', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Color(0xFFFFD700))),
                SizedBox(height: 4),
                Text('Monitor walk-in and scheduled customer bookings', style: TextStyle(color: Color(0xFFE0E0E0), fontSize: 14)),
              ],
            ),
          ),
          const SizedBox(width: 16),
          ElevatedButton.icon(
            onPressed: _showNewAppointmentDialog,
            icon: const Icon(BootstrapIcons.plus_circle, size: 20),
            label: const Text('New Appointment'),
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFFFFD700),
              foregroundColor: Colors.black,
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
              elevation: 4,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatsCards(Map<String, int> stats) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [Color(0xFF1A1A1A), Colors.black]),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFFFD700), width: 2),
      ),
      child: Wrap(
        spacing: 16,
        runSpacing: 16,
        children: [
          _buildStatCard('Total', stats['total']!, BootstrapIcons.calendar_check_fill, const Color(0xFF2196F3)),
          _buildStatCard('Pending', stats['pending']!, BootstrapIcons.clock_history, const Color(0xFFFFC107)),
          _buildStatCard('Confirmed', stats['confirmed']!, BootstrapIcons.check_circle_fill, const Color(0xFF4CAF50)),
          _buildStatCard('In-Progress', stats['in-progress']!, BootstrapIcons.arrow_repeat, const Color(0xFF2196F3)),
          _buildStatCard('Completed', stats['completed']!, BootstrapIcons.check_all, const Color(0xFF9E9E9E)),
        ],
      ),
    );
  }

  Widget _buildStatCard(String label, int count, IconData icon, Color color) {
    return Container(
      constraints: const BoxConstraints(minWidth: 200),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [Color(0xFF1A1A1A), Color(0xFF0A0A0A)]),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 50,
            height: 50,
            decoration: BoxDecoration(
              color: color.withOpacity(0.2),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: color.withOpacity(0.3), width: 2),
            ),
            child: Icon(icon, color: color, size: 24),
          ),
          const SizedBox(width: 16),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(count.toString(), style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: Color(0xFFFFD700))),
              const SizedBox(height: 4),
              Text(label, style: const TextStyle(color: Color(0xFFE0E0E0), fontSize: 12, fontWeight: FontWeight.w600)),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildFilterSection() {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [Color(0xFF1A1A1A), Colors.black]),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFFFD700), width: 2),
      ),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: const BoxDecoration(
              gradient: LinearGradient(colors: [Colors.black, Color(0xFF1A1A1A)]),
              borderRadius: BorderRadius.only(topLeft: Radius.circular(10), topRight: Radius.circular(10)),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Row(
                  children: [
                    Icon(BootstrapIcons.funnel, color: Color(0xFFFFD700), size: 18),
                    SizedBox(width: 8),
                    Text('FILTER APPOINTMENTS', style: TextStyle(color: Color(0xFFFFD700), fontWeight: FontWeight.bold, fontSize: 14)),
                  ],
                ),
                ElevatedButton.icon(
                  onPressed: _resetFilters,
                  icon: const Icon(BootstrapIcons.arrow_clockwise, size: 14),
                  label: const Text('Reset All'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFFFD700),
                    foregroundColor: Colors.black,
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(20),
            child: Row(
              children: [
                Expanded(flex: 2, child: _buildSearchField()),
                const SizedBox(width: 16),
                Expanded(child: _buildDateFilter()),
                const SizedBox(width: 16),
                Expanded(child: _buildStatusDropdown()),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSearchField() {
    return TextField(
      onChanged: (value) => setState(() => _searchQuery = value),
      decoration: InputDecoration(
        labelText: 'Search',
        labelStyle: const TextStyle(color: Color(0xFFFFD700)),
        hintText: 'Name, phone, or car plate...',
        hintStyle: TextStyle(color: const Color(0xFFFFD700).withOpacity(0.4)),
        prefixIcon: const Icon(BootstrapIcons.search, color: Color(0xFFFFD700)),
        filled: true,
        fillColor: Colors.black,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: Color(0xFFFFD700), width: 2)),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: Color(0xFFFFD700), width: 2)),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: Color(0xFFFFC700), width: 2)),
      ),
      style: const TextStyle(color: Color(0xFFFFD700)),
    );
  }

  Widget _buildDateFilter() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        const Text('Date', style: TextStyle(color: Color(0xFFFFD700), fontWeight: FontWeight.bold, fontSize: 12)),
        const SizedBox(height: 4),
        DropdownButtonFormField<String>(
          value: _dateFilter,
          onChanged: (value) {
            setState(() => _dateFilter = value!);
            if (value == 'custom') _selectCustomDate();
          },
          decoration: InputDecoration(
            prefixIcon: const Icon(BootstrapIcons.calendar3, color: Color(0xFFFFD700), size: 20),
            filled: true,
            fillColor: Colors.black,
            contentPadding: const EdgeInsets.symmetric(vertical: 14, horizontal: 12),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: Color(0xFFFFD700), width: 2)),
            enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: Color(0xFFFFD700), width: 2)),
            focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: Color(0xFFFFC700), width: 2)),
          ),
          dropdownColor: const Color(0xFF0A0A0A),
          style: const TextStyle(color: Color(0xFFFFD700), fontSize: 14, fontWeight: FontWeight.w600),
          items: const [
            DropdownMenuItem(value: 'all', child: Text('All Dates')),
            DropdownMenuItem(value: 'today', child: Text('Today')),
            DropdownMenuItem(value: 'tomorrow', child: Text('Tomorrow')),
            DropdownMenuItem(value: 'week', child: Text('This Week')),
            DropdownMenuItem(value: 'month', child: Text('This Month')),
            DropdownMenuItem(value: 'custom', child: Text('Select Date...')),
          ],
        ),
      ],
    );
  }

  Widget _buildStatusDropdown() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        const Text('Status', style: TextStyle(color: Color(0xFFFFD700), fontWeight: FontWeight.bold, fontSize: 12)),
        const SizedBox(height: 4),
        DropdownButtonFormField<String>(
          value: _selectedStatus,
          onChanged: (value) => setState(() => _selectedStatus = value!),
          decoration: InputDecoration(
            prefixIcon: const Icon(BootstrapIcons.bookmark, color: Color(0xFFFFD700), size: 20),
            filled: true,
            fillColor: Colors.black,
            contentPadding: const EdgeInsets.symmetric(vertical: 14, horizontal: 12),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: Color(0xFFFFD700), width: 2)),
            enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: Color(0xFFFFD700), width: 2)),
            focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: Color(0xFFFFC700), width: 2)),
          ),
          dropdownColor: const Color(0xFF0A0A0A),
          style: const TextStyle(color: Color(0xFFFFD700), fontSize: 14, fontWeight: FontWeight.w600),
          items: const [
            DropdownMenuItem(value: 'all', child: Text('All Status')),
            DropdownMenuItem(value: 'pending', child: Text('Pending')),
            DropdownMenuItem(value: 'confirmed', child: Text('Confirmed')),
            DropdownMenuItem(value: 'completed', child: Text('Completed')),
            DropdownMenuItem(value: 'cancelled', child: Text('Cancelled')),
          ],
        ),
      ],
    );
  }

  Future<void> _selectCustomDate() async {
    final date = await showDatePicker(
      context: context,
      initialDate: _customDate ?? DateTime.now(),
      firstDate: DateTime(2020),
      lastDate: DateTime(2030),
      builder: (context, child) => Theme(
        data: ThemeData.dark().copyWith(
          colorScheme: const ColorScheme.dark(primary: Color(0xFFFFD700), onPrimary: Colors.black, surface: Color(0xFF1A1A1A), onSurface: Color(0xFFFFD700)),
        ),
        child: child!,
      ),
    );
    if (date != null) setState(() => _customDate = date);
    else setState(() => _dateFilter = 'all');
  }

  Widget _buildStatusTabs(Map<String, int> stats) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [Color(0xFF1A1A1A), Colors.black]),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFFFD700), width: 2),
      ),
      child: Wrap(
        spacing: 8,
        runSpacing: 8,
        children: [
          _buildStatusTab('All', stats['total']!, 'all'),
          _buildStatusTab('Pending', stats['pending']!, 'pending'),
          _buildStatusTab('Confirmed', stats['confirmed']!, 'confirmed'),
          _buildStatusTab('In-Progress', stats['in-progress']!, 'in-progress'),
          _buildStatusTab('Completed', stats['completed']!, 'completed'),
          _buildStatusTab('Cancelled', stats['cancelled']!, 'cancelled'),
        ],
      ),
    );
  }

  Widget _buildStatusTab(String label, int count, String status) {
    final isSelected = _selectedStatus == status;
    return InkWell(
      onTap: () => setState(() => _selectedStatus = status),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        decoration: BoxDecoration(
          gradient: isSelected ? const LinearGradient(colors: [Color(0xFFFFD700), Color(0xFFFFC700)]) : null,
          color: isSelected ? null : Colors.black,
          border: Border.all(color: isSelected ? const Color(0xFFFFD700) : const Color(0xFFFFD700).withOpacity(0.3), width: 2),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(label, style: TextStyle(color: isSelected ? Colors.black : const Color(0xFFFFD700), fontWeight: FontWeight.bold, fontSize: 12)),
            const SizedBox(width: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
              decoration: BoxDecoration(
                color: isSelected ? Colors.black : const Color(0xFFFFD700).withOpacity(0.2),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(count.toString(), style: const TextStyle(color: Color(0xFFFFD700), fontWeight: FontWeight.bold, fontSize: 11)),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAppointmentsGrid(List<AppointmentModel> appointments) {
    if (appointments.isEmpty) {
      return Container(
        width: double.infinity,
        padding: const EdgeInsets.all(60),
        decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [Color(0xFF1A1A1A), Colors.black]),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: const Color(0xFFFFD700), width: 2),
        ),
        child: Center(
          child: Column(
            children: [
              Icon(BootstrapIcons.calendar_x, color: const Color(0xFFFFD700).withOpacity(0.5), size: 64),
              const SizedBox(height: 16),
              const Text('No appointments found', style: TextStyle(color: Color(0xFFFFD700), fontSize: 20, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              Text('Try adjusting your filters', style: TextStyle(color: const Color(0xFFFFD700).withOpacity(0.7), fontSize: 14)),
            ],
          ),
        ),
      );
    }

    // 🔧 RESPONSIVE GRID: Narrower and shorter cards with suitable height
    return LayoutBuilder(
      builder: (context, constraints) {
        int crossAxisCount = 4;
        double childAspectRatio = 1.0;
        
        // Calculate optimal columns based on available width
        if (constraints.maxWidth < 600) {
          crossAxisCount = 1; // Mobile: 1 column
          childAspectRatio = 1.4;
        } else if (constraints.maxWidth < 900) {
          crossAxisCount = 2; // Tablet: 2 columns
          childAspectRatio = 1.25;
        } else if (constraints.maxWidth < 1400) {
          crossAxisCount = 3; // Desktop: 3 columns
          childAspectRatio = 1.1; // ⭐ Narrower and suitable height
        } else {
          crossAxisCount = 4; // Large Desktop: 4 columns
          childAspectRatio = 1.05; // ⭐ Narrower and suitable height
        }

        return GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: crossAxisCount,
            childAspectRatio: childAspectRatio,
            crossAxisSpacing: 16,
            mainAxisSpacing: 16,
          ),
          itemCount: appointments.length,
          itemBuilder: (context, index) => _buildAppointmentCard(appointments[index], index),
        );
      },
    );
  }

  Widget _buildAppointmentCard(AppointmentModel appointment, int index) {
    final borderColor = _getCardBorderColor(index);
    final statusColor = _getStatusColor(appointment.status);
    
    // Safely get appointment type
    String appointmentType = 'scheduled';
    try {
      appointmentType = appointment.appointmentType?.toLowerCase() ?? 'scheduled';
    } catch (e) {
      appointmentType = 'scheduled';
    }
    
    // Safely get customer phone - FORMAT IT!
    String customerPhone = 'N/A';
    try {
      customerPhone = _formatPhoneNumber(appointment.customerPhone ?? 'N/A');
    } catch (e) {
      customerPhone = 'N/A';
    }
    
    // Safely get vehicle display
    String vehicleDisplay = '${appointment.vehicleBrand} ${appointment.vehicleModel}';
    
    // Check if status is in-progress
    final isInProgress = appointment.status.toLowerCase() == 'in-progress';
    final isCompleted = appointment.status.toLowerCase() == 'completed';
    final isCancelled = appointment.status.toLowerCase() == 'cancelled';
    
    // Determine badge text colors based on background brightness
    final typeColor = appointmentType == 'walk-in' ? const Color(0xFF9C27B0) : const Color(0xFF00BCD4);
    final typeTextColor = _isLightColor(typeColor) ? Colors.black : Colors.white;
    final statusTextColor = _isLightColor(statusColor) ? Colors.black : Colors.white;

    return Container(
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [Color(0xFF1A1A1A), Colors.black]),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: borderColor, width: 3),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          // Header with MORE HEIGHT - name bold, phone NOT bold
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14), // ⭐ More vertical space
            decoration: BoxDecoration(
              border: Border(bottom: BorderSide(color: const Color(0xFFFFD700).withOpacity(0.2), width: 1)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: Text(
                        appointment.customerName,
                        style: const TextStyle(
                          color: Color(0xFFFFD700), 
                          fontWeight: FontWeight.bold, // ✅ Name is BOLD
                          fontSize: 16,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                      decoration: BoxDecoration(
                        color: typeColor,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Text(
                        appointmentType == 'walk-in' ? 'WALK-IN' : 'SCHEDULED',
                        style: TextStyle(color: typeTextColor, fontSize: 9, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8), // ⭐ Better spacing between name and phone
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        const Icon(BootstrapIcons.telephone_fill, color: Color(0xFFFFD700), size: 12),
                        const SizedBox(width: 6),
                        Text(
                          customerPhone, 
                          style: const TextStyle(
                            color: Color(0xFFFFD700), 
                            fontSize: 12,
                            fontWeight: FontWeight.normal, // ✅ Phone is NOT bold
                          ),
                        ),
                      ],
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                      decoration: BoxDecoration(
                        color: statusColor,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Text(
                        isInProgress ? 'IN-PROGRESS' : appointment.status.toUpperCase(),
                        style: TextStyle(color: statusTextColor, fontSize: 9, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          
          // Content with SUITABLE GAPS - not too packed!
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10), // ⭐ Better spacing
            child: Column(
              children: [
                _buildCompactDetailRow(BootstrapIcons.calendar3, 'DATE', _formatDate(appointment.appointmentDate)),
                const SizedBox(height: 7), // ⭐ Suitable gap
                _buildCompactDetailRow(BootstrapIcons.clock, 'TIME', _formatTime(appointment.appointmentTime)),
                const SizedBox(height: 7), // ⭐ Suitable gap
                _buildCompactDetailRow(BootstrapIcons.car_front_fill, 'VEHICLE', '${appointment.vehiclePlate} • $vehicleDisplay'),
                const SizedBox(height: 7), // ⭐ Suitable gap
                _buildCompactDetailRow(BootstrapIcons.geo_alt_fill, 'BRANCH', _formatBranch(appointment.branchID)),
                const SizedBox(height: 7), // ⭐ Suitable gap
                _buildCompactDetailRow(BootstrapIcons.box_seam, 'PACKAGE', appointment.packageName),
              ],
            ),
          ),
          
          // Action buttons with SUITABLE LENGTH & HEIGHT - CLOSE TO CARD BOTTOM
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 0, 12, 12), // ⭐ Proper bottom padding
            child: Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: () => _viewAppointment(appointment),
                    icon: const Icon(BootstrapIcons.eye, size: 12),
                    label: const Text('VIEW', style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold)),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF2196F3),
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 9), // ⭐ Suitable padding
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
                    ),
                  ),
                ),
                if (!isInProgress && !isCompleted && !isCancelled) ...[
                  const SizedBox(width: 6),
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: () => _editAppointment(appointment),
                      icon: const Icon(BootstrapIcons.pencil, size: 12),
                      label: const Text('EDIT', style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold)),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFFFFC107),
                        foregroundColor: Colors.black,
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 9), // ⭐ Suitable padding
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
                      ),
                    ),
                  ),
                  const SizedBox(width: 6),
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: () => _showStatusDialog(appointment),
                      icon: const Icon(BootstrapIcons.arrow_repeat, size: 12),
                      label: const Text('STATUS', style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold)),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF4CAF50),
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 9), // ⭐ Suitable padding
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
                      ),
                    ),
                  ),
                ],
                const SizedBox(width: 6),
                Container(
                  decoration: BoxDecoration(
                    color: const Color(0xFFF44336),
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: IconButton(
                    onPressed: () => _deleteAppointment(appointment),
                    icon: const Icon(BootstrapIcons.trash, size: 14, color: Colors.white),
                    padding: const EdgeInsets.all(9), // ⭐ Suitable padding
                    constraints: const BoxConstraints(minWidth: 38, minHeight: 38), // ⭐ Suitable size
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // Helper function to determine if a color is light
  bool _isLightColor(Color color) {
    // Calculate relative luminance
    final double luminance = (0.299 * color.red + 0.587 * color.green + 0.114 * color.blue) / 255;
    return luminance > 0.5; // If luminance > 0.5, it's a light color
  }

  String _formatPhoneNumber(String phone) {
    // Remove any existing formatting
    phone = phone.replaceAll(RegExp(r'[^0-9]'), '');
    
    // Format as 012-3456789
    if (phone.length >= 10) {
      return '${phone.substring(0, 3)}-${phone.substring(3)}';
    } else if (phone.length >= 3) {
      return '${phone.substring(0, 3)}-${phone.substring(3)}';
    }
    return phone;
  }

  Widget _buildCompactDetailRow(IconData icon, String label, String value) {
    return Row(
      children: [
        Icon(icon, color: const Color(0xFFFFD700), size: 14),
        const SizedBox(width: 10),
        Expanded(
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                label, 
                style: TextStyle(
                  color: const Color(0xFFFFD700).withOpacity(0.7), // ✅ Shallow/lighter gold
                  fontSize: 11, 
                  fontWeight: FontWeight.normal, // ✅ NOT bold
                ),
              ),
              Flexible(
                child: Text(
                  value,
                  style: const TextStyle(
                    color: Color(0xFFFFD700), // ✅ Full gold color
                    fontSize: 12, 
                    fontWeight: FontWeight.bold, // ✅ BOLD
                  ),
                  textAlign: TextAlign.right,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  String _formatDate(String date) {
    try {
      final d = DateTime.parse(date);
      return DateFormat('MMM dd, yyyy').format(d);
    } catch (e) {
      return date;
    }
  }

  String _formatTime(String time) {
    try {
      final parts = time.split(':');
      final hour = int.parse(parts[0]);
      final minute = parts[1];
      final period = hour >= 12 ? 'PM' : 'AM';
      final displayHour = hour > 12 ? hour - 12 : (hour == 0 ? 12 : hour);
      return '$displayHour:$minute $period';
    } catch (e) {
      return time;
    }
  }

  String _formatBranch(String branchID) {
    if (branchID.toLowerCase().contains('melaka')) return 'Melaka';
    if (branchID.toLowerCase().contains('seremban')) return 'Seremban 2';
    return branchID;
  }

  void _viewAppointment(AppointmentModel appointment) {
    final isCompleted = appointment.status.toLowerCase() == 'completed';
    final isInProgress = appointment.status.toLowerCase() == 'in-progress';
    
    showDialog(
      context: context,
      builder: (context) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          width: 600,
          constraints: const BoxConstraints(maxHeight: 700),
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [Colors.black, Color(0xFF1A1A1A)]),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: const Color(0xFFFFD700), width: 3),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Header
              Container(
                padding: const EdgeInsets.all(20),
                decoration: const BoxDecoration(
                  gradient: LinearGradient(colors: [Colors.black, Color(0xFF1A1A1A)]),
                  borderRadius: BorderRadius.only(topLeft: Radius.circular(13), topRight: Radius.circular(13)),
                  border: Border(bottom: BorderSide(color: Color(0xFFFFD700), width: 3)),
                ),
                child: Row(
                  children: [
                    const Icon(BootstrapIcons.eye, color: Color(0xFFFFD700), size: 24),
                    const SizedBox(width: 12),
                    const Text('APPOINTMENT DETAILS', style: TextStyle(color: Color(0xFFFFD700), fontWeight: FontWeight.bold, fontSize: 18)),
                    const Spacer(),
                    IconButton(
                      onPressed: () => Navigator.pop(context),
                      icon: const Icon(Icons.close, color: Color(0xFFFFD700)),
                    ),
                  ],
                ),
              ),
              
              // Content
              Flexible(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    children: [
                      // Customer Information Section
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(colors: [Color(0xFFFFD700), Color(0xFFFFC700)]),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: const Row(
                          children: [
                            Icon(BootstrapIcons.person_circle, color: Colors.black, size: 20),
                            SizedBox(width: 12),
                            Text('CUSTOMER INFORMATION', style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 14)),
                          ],
                        ),
                      ),
                      const SizedBox(height: 16),
                      
                      _buildViewRow('NAME:', appointment.customerName),
                      const SizedBox(height: 12),
                      _buildViewRow('PHONE:', _formatPhoneNumber(appointment.customerPhone ?? 'N/A')),
                      
                      const SizedBox(height: 24),
                      
                      // Vehicle Information Section
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(colors: [Color(0xFFFFD700), Color(0xFFFFC700)]),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: const Row(
                          children: [
                            Icon(BootstrapIcons.car_front_fill, color: Colors.black, size: 20),
                            SizedBox(width: 12),
                            Text('VEHICLE INFORMATION', style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 14)),
                          ],
                        ),
                      ),
                      const SizedBox(height: 16),
                      
                      _buildViewRow('CAR MODEL:', '${appointment.vehicleBrand} ${appointment.vehicleModel}'),
                      const SizedBox(height: 12),
                      _buildViewRow('CAR PLATE:', appointment.vehiclePlate),
                      
                      const SizedBox(height: 24),
                      
                      // Appointment Details Section
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(colors: [Color(0xFFFFD700), Color(0xFFFFC700)]),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: const Row(
                          children: [
                            Icon(BootstrapIcons.calendar_check, color: Colors.black, size: 20),
                            SizedBox(width: 12),
                            Text('APPOINTMENT DETAILS', style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 14)),
                          ],
                        ),
                      ),
                      const SizedBox(height: 16),
                      
                      _buildViewRow('DATE:', _formatDate(appointment.appointmentDate)),
                      const SizedBox(height: 12),
                      _buildViewRow('TIME:', _formatTime(appointment.appointmentTime)),
                      const SizedBox(height: 12),
                      _buildViewRow('PACKAGE:', appointment.packageName),
                      const SizedBox(height: 12),
                      _buildViewRow('STATUS:', isInProgress ? 'IN-PROGRESS' : appointment.status.toUpperCase()),
                      
                      // Show finish time for completed appointments
                      if (isCompleted) ...[
                        const SizedBox(height: 12),
                        _buildViewRow('FINISH SERVICE TIME:', appointment.updatedAt != null 
                            ? DateFormat('dd/MM/yyyy hh:mm a').format(appointment.updatedAt!)
                            : 'N/A'),
                      ],
                      
                      if (appointment.notes != null && appointment.notes!.isNotEmpty) ...[
                        const SizedBox(height: 12),
                        _buildViewRow('NOTES:', appointment.notes!),
                      ],
                    ],
                  ),
                ),
              ),
              
              // Footer
              Container(
                padding: const EdgeInsets.all(20),
                decoration: const BoxDecoration(
                  gradient: LinearGradient(colors: [Colors.black, Color(0xFF1A1A1A)]),
                  borderRadius: BorderRadius.only(bottomLeft: Radius.circular(13), bottomRight: Radius.circular(13)),
                  border: Border(top: BorderSide(color: Color(0xFFFFD700), width: 2)),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    ElevatedButton(
                      onPressed: () => Navigator.pop(context),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.grey[800],
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      ),
                      child: const Text('CLOSE', style: TextStyle(fontWeight: FontWeight.bold)),
                    ),
                    // Hide Edit button for completed and in-progress
                    if (!isCompleted && !isInProgress)
                      ElevatedButton.icon(
                        onPressed: () {
                          Navigator.pop(context);
                          _editAppointment(appointment);
                        },
                        icon: const Icon(BootstrapIcons.pencil),
                        label: const Text('EDIT APPOINTMENT', style: TextStyle(fontWeight: FontWeight.bold)),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFFFFD700),
                          foregroundColor: Colors.black,
                          padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                        ),
                      ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildViewRow(String label, String value) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 8),
      decoration: BoxDecoration(
        border: Border(bottom: BorderSide(color: const Color(0xFFFFD700).withOpacity(0.2), width: 1)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(color: Color(0xFFFFD700), fontWeight: FontWeight.bold, fontSize: 13)),
          const SizedBox(width: 16),
          Expanded(
            child: Text(
              value,
              style: const TextStyle(color: Color(0xFFFFD700), fontSize: 13),
              textAlign: TextAlign.right,
            ),
          ),
        ],
      ),
    );
  }

  void _editAppointment(AppointmentModel appointment) {
    showDialog(
      context: context,
      builder: (context) => _EditAppointmentDialog(appointment: appointment, branchID: appointment.branchID),
    );
  }

  void _showStatusDialog(AppointmentModel appointment) {
    final currentStatus = appointment.status.toLowerCase();
    
    showDialog(
      context: context,
      builder: (context) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          width: 400,
          decoration: BoxDecoration(
            color: Colors.black,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: const Color(0xFFFFD700), width: 2),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Simple Header
              Container(
                padding: const EdgeInsets.all(16),
                decoration: const BoxDecoration(
                  color: Colors.black,
                  borderRadius: BorderRadius.only(topLeft: Radius.circular(10), topRight: Radius.circular(10)),
                ),
                child: Row(
                  children: [
                    const Text(
                      'Change Status',
                      style: TextStyle(color: Color(0xFFFFD700), fontWeight: FontWeight.bold, fontSize: 16),
                    ),
                    const Spacer(),
                    IconButton(
                      icon: const Icon(Icons.close, color: Color(0xFFFFD700)),
                      onPressed: () => Navigator.pop(context),
                      padding: EdgeInsets.zero,
                      constraints: const BoxConstraints(),
                    ),
                  ],
                ),
              ),
              
              // Status options in black box
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.black,
                  border: Border.all(color: const Color(0xFFFFD700).withOpacity(0.3), width: 1),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    if (currentStatus != 'pending')
                      _buildStatusChangeOption(
                        appointment,
                        'SET PENDING',
                        'pending',
                        BootstrapIcons.clock,
                        const Color(0xFFFFC107),
                      ),
                    if (currentStatus != 'confirmed')
                      _buildStatusChangeOption(
                        appointment,
                        'MARK CONFIRMED',
                        'confirmed',
                        BootstrapIcons.check_circle,
                        const Color(0xFF4CAF50),
                      ),
                    // Don't show in-progress - only staff can set this
                    if (currentStatus != 'completed')
                      _buildStatusChangeOption(
                        appointment,
                        'MARK COMPLETED',
                        'completed',
                        BootstrapIcons.check_all,
                        const Color(0xFF9E9E9E),
                      ),
                    if (currentStatus != 'cancelled')
                      _buildStatusChangeOption(
                        appointment,
                        'CANCEL',
                        'cancelled',
                        BootstrapIcons.x_circle,
                        const Color(0xFFF44336),
                      ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStatusChangeOption(
    AppointmentModel appointment,
    String label,
    String newStatus,
    IconData icon,
    Color color,
  ) {
    return InkWell(
      onTap: () {
        Navigator.pop(context);
        _confirmStatusChange(appointment, newStatus, label);
      },
      child: Container(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          color: color.withOpacity(0.15),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: color, width: 2),
        ),
        child: Row(
          children: [
            Icon(icon, color: color, size: 20),
            const SizedBox(width: 12),
            Text(
              label,
              style: TextStyle(color: color, fontWeight: FontWeight.bold, fontSize: 14),
            ),
          ],
        ),
      ),
    );
  }

  void _confirmStatusChange(AppointmentModel appointment, String newStatus, String label) async {
    // Show confirmation dialog
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          width: 400,
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [Colors.black, Color(0xFF1A1A1A)]),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: const Color(0xFFFFC107), width: 3),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Amber Header
              Container(
                padding: const EdgeInsets.all(20),
                decoration: const BoxDecoration(
                  gradient: LinearGradient(colors: [Color(0xFFFFC107), Color(0xFFFFA000)]),
                  borderRadius: BorderRadius.only(topLeft: Radius.circular(13), topRight: Radius.circular(13)),
                ),
                child: const Row(
                  children: [
                    Icon(BootstrapIcons.exclamation_triangle, color: Colors.black, size: 24),
                    SizedBox(width: 12),
                    Text('CONFIRM STATUS CHANGE', style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 16)),
                  ],
                ),
              ),
              
              // Content
              Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  children: [
                    const Text(
                      'Are you sure you want to change the appointment status?',
                      style: TextStyle(color: Color(0xFFFFD700), fontSize: 14),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 20),
                    
                    // Status Info Box
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.black,
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: const Color(0xFFFFD700), width: 2),
                      ),
                      child: Column(
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text(
                                'CURRENT STATUS:',
                                style: TextStyle(color: Color(0xFFFFD700), fontWeight: FontWeight.bold, fontSize: 13),
                              ),
                              Text(
                                appointment.status.toUpperCase(),
                                style: const TextStyle(color: Color(0xFFFFD700), fontSize: 13),
                              ),
                            ],
                          ),
                          const SizedBox(height: 12),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text(
                                'NEW STATUS:',
                                style: TextStyle(color: Color(0xFFFFD700), fontWeight: FontWeight.bold, fontSize: 13),
                              ),
                              Text(
                                newStatus.toUpperCase(),
                                style: const TextStyle(color: Color(0xFFFFD700), fontSize: 13),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    
                    const SizedBox(height: 20),
                    
                    // Buttons
                    Row(
                      children: [
                        Expanded(
                          child: ElevatedButton(
                            onPressed: () => Navigator.pop(context, false),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.grey[800],
                              foregroundColor: Colors.white,
                              padding: const EdgeInsets.symmetric(vertical: 16),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                            ),
                            child: const Text('CANCEL', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: ElevatedButton(
                            onPressed: () => Navigator.pop(context, true),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: const Color(0xFFFFC107),
                              foregroundColor: Colors.black,
                              padding: const EdgeInsets.symmetric(vertical: 16),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                            ),
                            child: const Text('CONFIRM CHANGE', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );

    if (confirmed == true) {
      try {
        await AppointmentService().updateAppointmentStatus(
          appointmentID: appointment.appointmentID,
          newStatus: newStatus,
        );
        
        if (mounted) {
          final authProvider = context.read<AuthProvider>();
          final managerProvider = context.read<ManagerProvider>();
          await managerProvider.fetchAppointments(authProvider.branchID!);
          
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Status updated to ${newStatus.toUpperCase()}'),
              backgroundColor: const Color(0xFF4CAF50),
            ),
          );
        }
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Error updating status: $e'), backgroundColor: Colors.red),
          );
        }
      }
    }
  }

  Future<void> _deleteAppointment(AppointmentModel appointment) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          width: 500,
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [Color(0xFF1A1A1A), Colors.black]),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: const Color(0xFFF44336), width: 3),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Red Header
              Container(
                padding: const EdgeInsets.all(20),
                decoration: const BoxDecoration(
                  gradient: LinearGradient(colors: [Color(0xFFF44336), Color(0xFFD32F2F)]),
                  borderRadius: BorderRadius.only(topLeft: Radius.circular(13), topRight: Radius.circular(13)),
                ),
                child: const Row(
                  children: [
                    Icon(BootstrapIcons.trash, color: Colors.white, size: 24),
                    SizedBox(width: 12),
                    Text('DELETE APPOINTMENT', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 18)),
                  ],
                ),
              ),
              
              // Content
              Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  children: [
                    const Text(
                      'Are you sure you want to delete this appointment?',
                      style: TextStyle(color: Color(0xFFFFD700), fontSize: 16, fontWeight: FontWeight.bold),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 20),
                    
                    // Warning Box
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: const Color(0xFFF44336).withOpacity(0.1),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: const Color(0xFFF44336), width: 2),
                      ),
                      child: const Row(
                        children: [
                          Icon(BootstrapIcons.exclamation_triangle, color: Color(0xFFF44336), size: 24),
                          SizedBox(width: 12),
                          Expanded(
                            child: Text(
                              'This action cannot be undone.',
                              style: TextStyle(color: Color(0xFFF44336), fontWeight: FontWeight.bold, fontSize: 14),
                            ),
                          ),
                        ],
                      ),
                    ),
                    
                    const SizedBox(height: 20),
                    
                    // Appointment Details
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.black,
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: const Color(0xFFFFD700), width: 2),
                      ),
                      child: Column(
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text('CUSTOMER:', style: TextStyle(color: Color(0xFFFFD700), fontWeight: FontWeight.bold, fontSize: 13)),
                              Text(appointment.customerName, style: const TextStyle(color: Color(0xFFFFD700), fontSize: 13)),
                            ],
                          ),
                          const SizedBox(height: 12),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text('DATE:', style: TextStyle(color: Color(0xFFFFD700), fontWeight: FontWeight.bold, fontSize: 13)),
                              Text('${_formatDate(appointment.appointmentDate)} at ${_formatTime(appointment.appointmentTime)}', style: const TextStyle(color: Color(0xFFFFD700), fontSize: 13)),
                            ],
                          ),
                        ],
                      ),
                    ),
                    
                    const SizedBox(height: 24),
                    
                    // Buttons
                    Row(
                      children: [
                        Expanded(
                          child: ElevatedButton(
                            onPressed: () => Navigator.pop(context, false),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.grey[800],
                              foregroundColor: Colors.white,
                              padding: const EdgeInsets.symmetric(vertical: 16),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                            ),
                            child: const Text('CANCEL', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: ElevatedButton.icon(
                            onPressed: () => Navigator.pop(context, true),
                            icon: const Icon(BootstrapIcons.trash),
                            label: const Text('DELETE APPOINTMENT', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: const Color(0xFFF44336),
                              foregroundColor: Colors.white,
                              padding: const EdgeInsets.symmetric(vertical: 16),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );

    if (confirm == true) {
      try {
        await AppointmentService().deleteAppointment(appointment.appointmentID);
        
        final authProvider = context.read<AuthProvider>();
        final managerProvider = context.read<ManagerProvider>();
        await managerProvider.fetchAppointments(authProvider.branchID!);
        
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Appointment deleted successfully'), backgroundColor: Color(0xFFF44336)),
          );
        }
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Error deleting: $e'), backgroundColor: Colors.red),
          );
        }
      }
    }
  }

  void _showNewAppointmentDialog() {
    final authProvider = context.read<AuthProvider>();
    if (authProvider.branchID == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Branch ID not found'), backgroundColor: Colors.red),
      );
      return;
    }
    
    showDialog(
      context: context,
      builder: (context) => NewAppointmentDialog(branchID: authProvider.branchID!),
    );
  }
}

// EDIT APPOINTMENT DIALOG
class _EditAppointmentDialog extends StatefulWidget {
  final AppointmentModel appointment;
  final String branchID;
  
  const _EditAppointmentDialog({required this.appointment, required this.branchID});

  @override
  State<_EditAppointmentDialog> createState() => _EditAppointmentDialogState();
}

class _EditAppointmentDialogState extends State<_EditAppointmentDialog> {
  final _formKey = GlobalKey<FormState>();
  final AppointmentService _appointmentService = AppointmentService();
  final PackageService _packageService = PackageService();
  
  late TextEditingController _nameController;
  late TextEditingController _phoneController;
  late TextEditingController _plateController;
  late TextEditingController _notesController;
  late DateTime _selectedDate;
  late TimeOfDay _selectedTime;
  late String _selectedBrand;
  late String _selectedModel;
  
  List<TintPackageModel> _packages = [];
  TintPackageModel? _selectedPackage;
  bool _isLoadingPackages = true;
  bool _isSaving = false;

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController(text: widget.appointment.customerName);
    _phoneController = TextEditingController(text: widget.appointment.customerPhone ?? '');
    _plateController = TextEditingController(text: widget.appointment.vehiclePlate);
    _notesController = TextEditingController(text: widget.appointment.notes ?? '');
    
    _selectedDate = DateTime.parse(widget.appointment.appointmentDate);
    final timeParts = widget.appointment.appointmentTime.split(':');
    _selectedTime = TimeOfDay(hour: int.parse(timeParts[0]), minute: int.parse(timeParts[1]));
    
    _selectedBrand = widget.appointment.vehicleBrand;
    _selectedModel = widget.appointment.vehicleModel;
    
    _loadPackages();
  }

  @override
  void dispose() {
    _nameController.dispose();
    _phoneController.dispose();
    _plateController.dispose();
    _notesController.dispose();
    super.dispose();
  }

  Future<void> _loadPackages() async {
    try {
      final packages = await _packageService.getAllPackages();
      setState(() {
        _packages = packages;
        _isLoadingPackages = false;
        _selectedPackage = packages.firstWhere(
          (p) => p.packageName == widget.appointment.packageName,
          orElse: () => packages.first,
        );
      });
    } catch (e) {
      setState(() => _isLoadingPackages = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      child: Container(
        width: 600,
        constraints: const BoxConstraints(maxHeight: 750),
        decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [Color(0xFF1A1A1A), Colors.black]),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: const Color(0xFFFFD700), width: 3),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Header
            Container(
              padding: const EdgeInsets.all(20),
              decoration: const BoxDecoration(
                gradient: LinearGradient(colors: [Colors.black, Color(0xFF1A1A1A)]),
                borderRadius: BorderRadius.only(topLeft: Radius.circular(13), topRight: Radius.circular(13)),
                border: Border(bottom: BorderSide(color: Color(0xFFFFD700), width: 3)),
              ),
              child: Row(
                children: [
                  const Icon(BootstrapIcons.pencil, color: Color(0xFFFFD700), size: 24),
                  const SizedBox(width: 12),
                  const Text('EDIT APPOINTMENT', style: TextStyle(color: Color(0xFFFFD700), fontWeight: FontWeight.bold, fontSize: 18)),
                  const Spacer(),
                  IconButton(
                    onPressed: _isSaving ? null : () => Navigator.pop(context),
                    icon: const Icon(Icons.close, color: Color(0xFFFFD700)),
                  ),
                ],
              ),
            ),
            
            // Content
            Flexible(
              child: _isLoadingPackages
                  ? const Center(child: CircularProgressIndicator(valueColor: AlwaysStoppedAnimation<Color>(Color(0xFFFFD700))))
                  : SingleChildScrollView(
                      padding: const EdgeInsets.all(24),
                      child: Form(
                        key: _formKey,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            _buildEditField('CUSTOMER NAME', _nameController, BootstrapIcons.person_fill),
                            const SizedBox(height: 16),
                            _buildEditField('PHONE NUMBER', _phoneController, BootstrapIcons.telephone_fill),
                            const SizedBox(height: 16),
                            _buildEditField('CAR PLATE NUMBER', _plateController, BootstrapIcons.car_front_fill),
                            const SizedBox(height: 16),
                            
                            // Car Model (read-only)
                            _buildReadOnlyField('CAR MODEL', '$_selectedBrand $_selectedModel', BootstrapIcons.car_front_fill),
                            const SizedBox(height: 16),
                            
                            // Date Picker
                            _buildDatePicker(),
                            const SizedBox(height: 16),
                            
                            // Time Picker
                            _buildTimePicker(),
                            const SizedBox(height: 16),
                            
                            // Branch (read-only)
                            _buildReadOnlyField('BRANCH', widget.branchID == 'melaka' ? 'Melaka' : 'Seremban 2', BootstrapIcons.geo_alt_fill),
                            const SizedBox(height: 16),
                            
                            // Package Dropdown
                            if (_packages.isNotEmpty) _buildPackageDropdown(),
                            const SizedBox(height: 16),
                            
                            // Notes
                            _buildEditField('SPECIAL NOTES', _notesController, BootstrapIcons.sticky, maxLines: 3),
                          ],
                        ),
                      ),
                    ),
            ),
            
            // Footer
            Container(
              padding: const EdgeInsets.all(20),
              decoration: const BoxDecoration(
                gradient: LinearGradient(colors: [Colors.black, Color(0xFF1A1A1A)]),
                borderRadius: BorderRadius.only(bottomLeft: Radius.circular(13), bottomRight: Radius.circular(13)),
                border: Border(top: BorderSide(color: Color(0xFFFFD700), width: 2)),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  ElevatedButton(
                    onPressed: _isSaving ? null : () => Navigator.pop(context),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.grey[800],
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                    ),
                    child: const Text('CANCEL', style: TextStyle(fontWeight: FontWeight.bold)),
                  ),
                  const SizedBox(width: 12),
                  ElevatedButton.icon(
                    onPressed: _isSaving ? null : _saveChanges,
                    icon: _isSaving
                        ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, valueColor: AlwaysStoppedAnimation<Color>(Colors.black)))
                        : const Icon(BootstrapIcons.download),
                    label: Text(_isSaving ? 'SAVING...' : 'SAVE CHANGES', style: const TextStyle(fontWeight: FontWeight.bold)),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFFFD700),
                      foregroundColor: Colors.black,
                      padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEditField(String label, TextEditingController controller, IconData icon, {int maxLines = 1}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(color: Color(0xFFFFD700), fontWeight: FontWeight.bold, fontSize: 13)),
        const SizedBox(height: 8),
        TextFormField(
          controller: controller,
          enabled: !_isSaving,
          maxLines: maxLines,
          style: const TextStyle(color: Color(0xFFFFD700)),
          decoration: InputDecoration(
            prefixIcon: Icon(icon, color: const Color(0xFFFFD700), size: 20),
            filled: true,
            fillColor: Colors.black,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: Color(0xFFFFD700), width: 2)),
            enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: Color(0xFFFFD700), width: 2)),
            focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: Color(0xFFFFC700), width: 2)),
          ),
        ),
      ],
    );
  }

  Widget _buildReadOnlyField(String label, String value, IconData icon) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(color: Color(0xFFFFD700), fontWeight: FontWeight.bold, fontSize: 13)),
        const SizedBox(height: 8),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.black.withOpacity(0.5),
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: const Color(0xFFFFD700).withOpacity(0.5), width: 2),
          ),
          child: Row(
            children: [
              Icon(icon, color: const Color(0xFFFFD700).withOpacity(0.5), size: 20),
              const SizedBox(width: 12),
              Text(value, style: TextStyle(color: const Color(0xFFFFD700).withOpacity(0.7), fontSize: 14)),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildDatePicker() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('APPOINTMENT DATE', style: TextStyle(color: Color(0xFFFFD700), fontWeight: FontWeight.bold, fontSize: 13)),
        const SizedBox(height: 8),
        InkWell(
          onTap: _isSaving ? null : () async {
            final date = await showDatePicker(
              context: context,
              initialDate: _selectedDate,
              firstDate: DateTime.now(),
              lastDate: DateTime.now().add(const Duration(days: 365)),
              builder: (context, child) => Theme(
                data: ThemeData.dark().copyWith(
                  colorScheme: const ColorScheme.dark(primary: Color(0xFFFFD700), onPrimary: Colors.black, surface: Color(0xFF1A1A1A), onSurface: Color(0xFFFFD700)),
                ),
                child: child!,
              ),
            );
            if (date != null) setState(() => _selectedDate = date);
          },
          child: Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.black,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: const Color(0xFFFFD700), width: 2),
            ),
            child: Row(
              children: [
                const Icon(BootstrapIcons.calendar3, color: Color(0xFFFFD700)),
                const SizedBox(width: 12),
                Text(
                  DateFormat('dd/MM/yyyy').format(_selectedDate),
                  style: const TextStyle(color: Color(0xFFFFD700), fontWeight: FontWeight.w600),
                ),
                const Spacer(),
                const Icon(BootstrapIcons.calendar_event, color: Color(0xFFFFD700), size: 16),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildTimePicker() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('APPOINTMENT TIME', style: TextStyle(color: Color(0xFFFFD700), fontWeight: FontWeight.bold, fontSize: 13)),
        const SizedBox(height: 8),
        InkWell(
          onTap: _isSaving ? null : () async {
            final time = await showTimePicker(
              context: context,
              initialTime: _selectedTime,
              builder: (context, child) => Theme(
                data: ThemeData.dark().copyWith(
                  colorScheme: const ColorScheme.dark(primary: Color(0xFFFFD700), onPrimary: Colors.black, surface: Color(0xFF1A1A1A), onSurface: Color(0xFFFFD700)),
                ),
                child: child!,
              ),
            );
            if (time != null) setState(() => _selectedTime = time);
          },
          child: Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.black,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: const Color(0xFFFFD700), width: 2),
            ),
            child: Row(
              children: [
                const Icon(BootstrapIcons.clock, color: Color(0xFFFFD700)),
                const SizedBox(width: 12),
                Text(
                  _selectedTime.format(context),
                  style: const TextStyle(color: Color(0xFFFFD700), fontWeight: FontWeight.w600),
                ),
                const Spacer(),
                const Icon(BootstrapIcons.clock_fill, color: Color(0xFFFFD700), size: 16),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildPackageDropdown() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('SERVICE PACKAGE', style: TextStyle(color: Color(0xFFFFD700), fontWeight: FontWeight.bold, fontSize: 13)),
        const SizedBox(height: 8),
        DropdownButtonFormField<TintPackageModel>(
          value: _selectedPackage,
          onChanged: _isSaving ? null : (value) => setState(() => _selectedPackage = value),
          decoration: InputDecoration(
            prefixIcon: const Icon(BootstrapIcons.box_seam, color: Color(0xFFFFD700), size: 20),
            filled: true,
            fillColor: Colors.black,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: Color(0xFFFFD700), width: 2)),
            enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: Color(0xFFFFD700), width: 2)),
            focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: Color(0xFFFFC700), width: 2)),
          ),
          dropdownColor: const Color(0xFF0A0A0A),
          style: const TextStyle(color: Color(0xFFFFD700), fontSize: 14, fontWeight: FontWeight.w600),
          items: _packages.map((package) => DropdownMenuItem(value: package, child: Text(package.packageName))).toList(),
        ),
      ],
    );
  }

  Future<void> _saveChanges() async {
    if (!_formKey.currentState!.validate()) return;
    
    setState(() => _isSaving = true);

    try {
      final hour = _selectedTime.hour.toString().padLeft(2, '0');
      final minute = _selectedTime.minute.toString().padLeft(2, '0');
      
      await _appointmentService.updateAppointmentStatus(
        appointmentID: widget.appointment.appointmentID,
        newStatus: widget.appointment.status, // Keep same status
      );
      
      if (mounted) {
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Appointment updated successfully!'), backgroundColor: Color(0xFF4CAF50)),
        );
        
        final manager = context.read<ManagerProvider>();
        await manager.fetchAppointments(widget.branchID);
      }
    } catch (e) {
      setState(() => _isSaving = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to update: $e'), backgroundColor: Colors.red),
        );
      }
    }
  }
}

// NEW APPOINTMENT DIALOG
class NewAppointmentDialog extends StatefulWidget {
  final String branchID;
  
  const NewAppointmentDialog({super.key, required this.branchID});

  @override
  State<NewAppointmentDialog> createState() => _NewAppointmentDialogState();
}

class _NewAppointmentDialogState extends State<NewAppointmentDialog> {
  final _formKey = GlobalKey<FormState>();
  final AppointmentService _appointmentService = AppointmentService();
  final PackageService _packageService = PackageService();
  
  String _appointmentType = 'scheduled';
  final _nameController = TextEditingController();
  final _phoneController = TextEditingController();
  final _plateController = TextEditingController();
  final _notesController = TextEditingController();
  DateTime? _selectedDate;
  TimeOfDay? _selectedTime;
  
  String? _selectedBrand;
  String? _selectedModel;
  List<String> _availableModels = [];
  String _detectedCarType = '';
  int _estimatedMinutes = 0;
  
  List<TintPackageModel> _packages = [];
  TintPackageModel? _selectedPackage;
  bool _isLoadingPackages = true;
  double _calculatedPrice = 0.0;
  
  bool _isSaving = false;

  @override
  void initState() {
    super.initState();
    _loadPackages();
  }

  @override
  void dispose() {
    _nameController.dispose();
    _phoneController.dispose();
    _plateController.dispose();
    _notesController.dispose();
    super.dispose();
  }

  Future<void> _loadPackages() async {
    try {
      final packages = await _packageService.getAllPackages();
      setState(() {
        _packages = packages;
        _isLoadingPackages = false;
        if (_packages.isNotEmpty) {
          _selectedPackage = _packages.first;
          _updatePrice();
        }
      });
    } catch (e) {
      setState(() => _isLoadingPackages = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to load packages: $e'), backgroundColor: Colors.red),
        );
      }
    }
  }

  void _onBrandChanged(String? brand) {
    if (brand != null) {
      setState(() {
        _selectedBrand = brand;
        _selectedModel = null;
        _availableModels = VehicleDatabase.getModelsByBrand(brand);
        _detectedCarType = '';
        _estimatedMinutes = 0;
        _calculatedPrice = 0.0;
      });
    }
  }

  void _onModelChanged(String? model) {
    if (model != null) {
      setState(() {
        _selectedModel = model;
        _detectedCarType = VehicleDatabase.getType(model);
        _estimatedMinutes = VehicleDatabase.getMinutes(model);
        _updatePrice();
      });
    }
  }

  void _onPackageChanged(TintPackageModel? package) {
    if (package != null) {
      setState(() {
        _selectedPackage = package;
        _updatePrice();
      });
    }
  }

  void _updatePrice() {
    if (_selectedPackage != null && _detectedCarType.isNotEmpty) {
      setState(() {
        _calculatedPrice = _selectedPackage!.getPriceForVehicle(_detectedCarType);
        final packageDuration = _selectedPackage!.getDurationForVehicle(_detectedCarType);
        if (packageDuration > 0) {
          _estimatedMinutes = packageDuration;
        }
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      child: Container(
        width: 600,
        constraints: const BoxConstraints(maxHeight: 750),
        decoration: BoxDecoration(
          gradient: const LinearGradient(colors: [Color(0xFF1A1A1A), Colors.black]),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: const Color(0xFFFFD700), width: 3),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: const BoxDecoration(
                gradient: LinearGradient(colors: [Colors.black, Color(0xFF1A1A1A), Colors.black]),
                borderRadius: BorderRadius.only(topLeft: Radius.circular(13), topRight: Radius.circular(13)),
                border: Border(bottom: BorderSide(color: Color(0xFFFFD700), width: 3)),
              ),
              child: Row(
                children: [
                  const Icon(BootstrapIcons.plus_circle, color: Color(0xFFFFD700), size: 24),
                  const SizedBox(width: 12),
                  const Text('CREATE NEW APPOINTMENT', style: TextStyle(color: Color(0xFFFFD700), fontWeight: FontWeight.bold, fontSize: 18)),
                  const Spacer(),
                  IconButton(
                    onPressed: _isSaving ? null : () => Navigator.pop(context), 
                    icon: const Icon(Icons.close, color: Color(0xFFFFD700))
                  ),
                ],
              ),
            ),
            
            Flexible(
              child: _isLoadingPackages
                  ? const Center(child: CircularProgressIndicator(valueColor: AlwaysStoppedAnimation<Color>(Color(0xFFFFD700))))
                  : SingleChildScrollView(
                      padding: const EdgeInsets.all(24),
                      child: Form(
                        key: _formKey,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Expanded(child: _buildTypeOption('scheduled', 'Scheduled', BootstrapIcons.calendar_check)),
                                const SizedBox(width: 16),
                                Expanded(child: _buildTypeOption('walk-in', 'Walk-In', BootstrapIcons.person_walking)),
                              ],
                            ),
                            const SizedBox(height: 24),
                            
                            _buildTextField(_nameController, 'Customer Name', BootstrapIcons.person_fill, 'Ahmad Ibrahim', 
                              [FilteringTextInputFormatter.allow(RegExp(r"[a-zA-Z\s]")), LengthLimitingTextInputFormatter(50)],
                              (v) => v == null || v.isEmpty ? 'Required' : v.length < 2 ? 'At least 2 characters' : null),
                            const SizedBox(height: 16),
                            
                            _buildTextField(_phoneController, 'Phone Number', BootstrapIcons.telephone_fill, '0123456789',
                              [FilteringTextInputFormatter.allow(RegExp(r'[0-9]')), LengthLimitingTextInputFormatter(11)],
                              (v) => v == null || v.isEmpty ? 'Required' : v.length < 10 ? 'At least 10 digits' : !v.startsWith('01') ? 'Must start with 01' : null,
                              keyboardType: TextInputType.phone),
                            const SizedBox(height: 16),
                            
                            _buildTextField(_plateController, 'Vehicle Plate', BootstrapIcons.car_front_fill, 'ABC 1234',
                              [FilteringTextInputFormatter.allow(RegExp(r'[A-Za-z0-9\s]')), LengthLimitingTextInputFormatter(10),
                               TextInputFormatter.withFunction((old, newValue) => TextEditingValue(text: newValue.text.toUpperCase(), selection: newValue.selection))],
                              (v) => v == null || v.isEmpty ? 'Required' : v.length < 4 ? 'Invalid' : null),
                            const SizedBox(height: 16),
                            
                            _buildSmartDropdown(value: _selectedBrand, label: 'Vehicle Brand', icon: BootstrapIcons.car_front, hint: 'Select brand',
                              items: VehicleDatabase.getAllBrands(), onChanged: _onBrandChanged, validator: (v) => v == null ? 'Select a brand' : null),
                            const SizedBox(height: 16),
                            
                            _buildSmartDropdown(value: _selectedModel, label: 'Vehicle Model', icon: BootstrapIcons.car_front_fill, hint: 'Select model',
                              items: _availableModels, onChanged: _onModelChanged, enabled: _selectedBrand != null, validator: (v) => v == null ? 'Select a model' : null),
                            
                            if (_detectedCarType.isNotEmpty) ...[const SizedBox(height: 16), _buildDetectedInfo()],
                            if (_appointmentType == 'scheduled') ...[const SizedBox(height: 16), _buildDatePicker()],
                            const SizedBox(height: 16),
                            _buildTimePicker(),
                            const SizedBox(height: 16),
                            
                            _buildPackageDropdown(),
                            const SizedBox(height: 16),
                            
                            if (_calculatedPrice > 0) ...[
                              Container(
                                padding: const EdgeInsets.all(16),
                                decoration: BoxDecoration(
                                  gradient: const LinearGradient(colors: [Color(0xFFFFF9E6), Color(0xFFFFF3CC)]),
                                  borderRadius: BorderRadius.circular(8),
                                  border: Border.all(color: const Color(0xFFFFD700), width: 2),
                                ),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    const Row(
                                      children: [
                                        Icon(BootstrapIcons.cash_stack, color: Color(0xFFFFD700), size: 20),
                                        SizedBox(width: 8),
                                        Text('Total Price', style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 16)),
                                      ],
                                    ),
                                    Text('RM ${_calculatedPrice.toStringAsFixed(2)}', style: const TextStyle(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 20)),
                                  ],
                                ),
                              ),
                              const SizedBox(height: 16),
                            ],
                            
                            _buildTextField(_notesController, 'Notes (Optional - Max 200 characters)', BootstrapIcons.sticky, 'Add any special requests...',
                              [LengthLimitingTextInputFormatter(200)], null, keyboardType: TextInputType.multiline, maxLines: 3),
                            
                            Align(
                              alignment: Alignment.centerRight,
                              child: Padding(
                                padding: const EdgeInsets.only(top: 4),
                                child: Text('${_notesController.text.length}/200',
                                  style: TextStyle(color: _notesController.text.length > 200 ? Colors.red : const Color(0xFFFFD700).withOpacity(0.6), fontSize: 11, fontWeight: FontWeight.w600)),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
            ),
            
            Container(
              padding: const EdgeInsets.all(20),
              decoration: const BoxDecoration(
                gradient: LinearGradient(colors: [Colors.black, Color(0xFF1A1A1A)]),
                borderRadius: BorderRadius.only(bottomLeft: Radius.circular(13), bottomRight: Radius.circular(13)),
                border: Border(top: BorderSide(color: Color(0xFFFFD700), width: 2)),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  TextButton(onPressed: _isSaving ? null : () => Navigator.pop(context), style: TextButton.styleFrom(foregroundColor: Colors.grey),
                    child: const Text('Cancel')),
                  const SizedBox(width: 12),
                  ElevatedButton.icon(
                    onPressed: _isSaving ? null : _saveAppointment,
                    icon: _isSaving ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, valueColor: AlwaysStoppedAnimation<Color>(Colors.black)))
                        : const Icon(BootstrapIcons.check_circle),
                    label: Text(_isSaving ? 'Creating...' : 'Create Appointment'),
                    style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFFFD700), foregroundColor: Colors.black, padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12)),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTypeOption(String value, String label, IconData icon) {
    final isSelected = _appointmentType == value;
    return InkWell(
      onTap: () => setState(() => _appointmentType = value),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          gradient: isSelected ? const LinearGradient(colors: [Color(0xFFFFD700), Color(0xFFFFC700)]) : null,
          color: isSelected ? null : Colors.black,
          border: Border.all(color: isSelected ? const Color(0xFFFFD700) : const Color(0xFFFFD700).withOpacity(0.3), width: 2),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Column(
          children: [
            Icon(icon, color: isSelected ? Colors.black : const Color(0xFFFFD700), size: 32),
            const SizedBox(height: 8),
            Text(label, style: TextStyle(color: isSelected ? Colors.black : const Color(0xFFFFD700), fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }

  Widget _buildTextField(TextEditingController controller, String label, IconData icon, String hint, List<TextInputFormatter> formatters,
    String? Function(String?)? validator, {TextInputType? keyboardType, int maxLines = 1}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(color: Color(0xFFFFD700), fontWeight: FontWeight.bold, fontSize: 14)),
        const SizedBox(height: 8),
        TextFormField(
          controller: controller,
          keyboardType: keyboardType,
          inputFormatters: formatters,
          validator: validator,
          maxLines: maxLines,
          enabled: !_isSaving,
          onChanged: (_) => setState(() {}),
          decoration: InputDecoration(
            hintText: hint,
            hintStyle: TextStyle(color: const Color(0xFFFFD700).withOpacity(0.4)),
            prefixIcon: Icon(icon, color: const Color(0xFFFFD700)),
            filled: true,
            fillColor: Colors.black,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: Color(0xFFFFD700), width: 2)),
            enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: Color(0xFFFFD700), width: 2)),
            focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: Color(0xFFFFC700), width: 2)),
            errorBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: Colors.red, width: 2)),
          ),
          style: const TextStyle(color: Color(0xFFFFD700)),
        ),
      ],
    );
  }

  Widget _buildSmartDropdown({required String? value, required String label, required IconData icon, required String hint, required List<String> items,
    required void Function(String?) onChanged, bool enabled = true, String? Function(String?)? validator}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(color: Color(0xFFFFD700), fontWeight: FontWeight.bold, fontSize: 14)),
        const SizedBox(height: 8),
        DropdownButtonFormField<String>(
          value: value,
          onChanged: enabled && !_isSaving ? onChanged : null,
          validator: validator,
          decoration: InputDecoration(
            hintText: hint,
            hintStyle: TextStyle(color: const Color(0xFFFFD700).withOpacity(0.4)),
            prefixIcon: Icon(icon, color: const Color(0xFFFFD700), size: 20),
            filled: true,
            fillColor: enabled ? Colors.black : Colors.black.withOpacity(0.5),
            contentPadding: const EdgeInsets.symmetric(vertical: 14, horizontal: 12),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: Color(0xFFFFD700), width: 2)),
            enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: Color(0xFFFFD700), width: 2)),
            focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: Color(0xFFFFC700), width: 2)),
            disabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: BorderSide(color: const Color(0xFFFFD700).withOpacity(0.3), width: 2)),
          ),
          dropdownColor: const Color(0xFF0A0A0A),
          style: const TextStyle(color: Color(0xFFFFD700), fontSize: 14, fontWeight: FontWeight.w600),
          icon: const Icon(Icons.arrow_drop_down, color: Color(0xFFFFD700), size: 24),
          isExpanded: true,
          menuMaxHeight: 300,
          items: items.map((item) => DropdownMenuItem<String>(value: item, child: Text(item))).toList(),
        ),
      ],
    );
  }

  Widget _buildPackageDropdown() {
    if (_packages.isEmpty) {
      return Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: Colors.red.withOpacity(0.1), borderRadius: BorderRadius.circular(8), border: Border.all(color: Colors.red, width: 2)),
        child: const Row(
          children: [
            Icon(BootstrapIcons.exclamation_triangle, color: Colors.red),
            SizedBox(width: 12),
            Expanded(child: Text('No packages available. Please add packages first.', style: TextStyle(color: Colors.red, fontWeight: FontWeight.w600))),
          ],
        ),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Service Package', style: TextStyle(color: Color(0xFFFFD700), fontWeight: FontWeight.bold, fontSize: 14)),
        const SizedBox(height: 8),
        DropdownButtonFormField<TintPackageModel>(
          value: _selectedPackage,
          onChanged: _isSaving ? null : _onPackageChanged,
          decoration: InputDecoration(
            hintText: 'Select package',
            hintStyle: TextStyle(color: const Color(0xFFFFD700).withOpacity(0.4)),
            prefixIcon: const Icon(BootstrapIcons.box_seam, color: Color(0xFFFFD700), size: 20),
            filled: true,
            fillColor: Colors.black,
            contentPadding: const EdgeInsets.symmetric(vertical: 14, horizontal: 12),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: Color(0xFFFFD700), width: 2)),
            enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: Color(0xFFFFD700), width: 2)),
            focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: Color(0xFFFFC700), width: 2)),
          ),
          dropdownColor: const Color(0xFF0A0A0A),
          style: const TextStyle(color: Color(0xFFFFD700), fontSize: 14, fontWeight: FontWeight.w600),
          icon: const Icon(Icons.arrow_drop_down, color: Color(0xFFFFD700), size: 24),
          isExpanded: true,
          menuMaxHeight: 300,
          items: _packages.map((package) => DropdownMenuItem<TintPackageModel>(value: package, child: Text(package.packageName))).toList(),
        ),
      ],
    );
  }

  Widget _buildDetectedInfo() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [Color(0xFFFFF9E6), Color(0xFFFFF3CC)]),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: const Color(0xFFFFD700), width: 2),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(
            children: [
              Icon(BootstrapIcons.info_circle, color: Color(0xFFFFD700), size: 20),
              SizedBox(width: 8),
              Text('Auto-Detected', style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(child: _buildInfoChip('Type', _detectedCarType, BootstrapIcons.car_front_fill)),
              const SizedBox(width: 12),
              Expanded(child: _buildInfoChip('Est. Time', '$_estimatedMinutes min', BootstrapIcons.clock)),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildInfoChip(String label, String value, IconData icon) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(8), border: Border.all(color: const Color(0xFFFFD700))),
      child: Column(
        children: [
          Icon(icon, color: const Color(0xFFFFD700), size: 20),
          const SizedBox(height: 4),
          Text(label, style: TextStyle(color: Colors.grey[600], fontSize: 10, fontWeight: FontWeight.w600)),
          Text(value, style: const TextStyle(color: Colors.black, fontSize: 14, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }

  Widget _buildDatePicker() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Appointment Date', style: TextStyle(color: Color(0xFFFFD700), fontWeight: FontWeight.bold, fontSize: 14)),
        const SizedBox(height: 8),
        InkWell(
          onTap: _isSaving ? null : () async {
            final date = await showDatePicker(
              context: context,
              initialDate: _selectedDate ?? DateTime.now(),
              firstDate: DateTime.now(),
              lastDate: DateTime.now().add(const Duration(days: 365)),
              builder: (context, child) => Theme(data: ThemeData.dark().copyWith(
                colorScheme: const ColorScheme.dark(primary: Color(0xFFFFD700), onPrimary: Colors.black, surface: Color(0xFF1A1A1A), onSurface: Color(0xFFFFD700))), child: child!),
            );
            if (date != null) setState(() => _selectedDate = date);
          },
          child: Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(color: Colors.black, border: Border.all(color: const Color(0xFFFFD700), width: 2), borderRadius: BorderRadius.circular(8)),
            child: Row(
              children: [
                const Icon(BootstrapIcons.calendar3, color: Color(0xFFFFD700)),
                const SizedBox(width: 12),
                Text(_selectedDate == null ? 'Select Date' : DateFormat('EEEE, MMM dd, yyyy').format(_selectedDate!),
                  style: TextStyle(color: _selectedDate == null ? const Color(0xFFFFD700).withOpacity(0.4) : const Color(0xFFFFD700), fontWeight: FontWeight.w600)),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildTimePicker() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const Text('Appointment Time', style: TextStyle(color: Color(0xFFFFD700), fontWeight: FontWeight.bold, fontSize: 14)),
            if (_estimatedMinutes > 0) ...[
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(color: const Color(0xFFFFD700).withOpacity(0.2), borderRadius: BorderRadius.circular(12), border: Border.all(color: const Color(0xFFFFD700))),
                child: Text('Allow $_estimatedMinutes min', style: const TextStyle(color: Color(0xFFFFD700), fontSize: 10, fontWeight: FontWeight.bold)),
              ),
            ],
          ],
        ),
        const SizedBox(height: 8),
        InkWell(
          onTap: _isSaving ? null : () async {
            final time = await showTimePicker(context: context, initialTime: _selectedTime ?? TimeOfDay.now(),
              builder: (context, child) => Theme(data: ThemeData.dark().copyWith(
                colorScheme: const ColorScheme.dark(primary: Color(0xFFFFD700), onPrimary: Colors.black, surface: Color(0xFF1A1A1A), onSurface: Color(0xFFFFD700))), child: child!));
            if (time != null) setState(() => _selectedTime = time);
          },
          child: Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(color: Colors.black, border: Border.all(color: const Color(0xFFFFD700), width: 2), borderRadius: BorderRadius.circular(8)),
            child: Row(
              children: [
                const Icon(BootstrapIcons.clock, color: Color(0xFFFFD700)),
                const SizedBox(width: 12),
                Text(_selectedTime == null ? 'Select Time' : _selectedTime!.format(context),
                  style: TextStyle(color: _selectedTime == null ? const Color(0xFFFFD700).withOpacity(0.4) : const Color(0xFFFFD700), fontWeight: FontWeight.w600)),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Future<void> _saveAppointment() async {
    if (!_formKey.currentState!.validate()) return;
    
    if (_selectedBrand == null || _selectedModel == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Please select vehicle brand and model'), backgroundColor: Colors.red));
      return;
    }
    
    if (_appointmentType == 'scheduled' && _selectedDate == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Please select a date'), backgroundColor: Colors.red));
      return;
    }
    
    if (_selectedTime == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Please select a time'), backgroundColor: Colors.red));
      return;
    }
    
    if (_selectedPackage == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Please select a package'), backgroundColor: Colors.red));
      return;
    }

    setState(() => _isSaving = true);

    try {
      final appointmentDate = _appointmentType == 'scheduled' ? DateFormat('yyyy-MM-dd').format(_selectedDate!) : DateFormat('yyyy-MM-dd').format(DateTime.now());
      final hour = _selectedTime!.hour.toString().padLeft(2, '0');
      final minute = _selectedTime!.minute.toString().padLeft(2, '0');
      final appointmentTime = '$hour:$minute';

      final appointmentID = await _appointmentService.createAppointment(
        customerName: _nameController.text.trim(),
        customerPhone: _phoneController.text.trim(),
        branchID: widget.branchID,
        vehicleBrand: _selectedBrand!,
        vehicleModel: _selectedModel!,
        vehicleType: _detectedCarType,
        vehiclePlate: _plateController.text.trim(),
        packageID: _selectedPackage!.packageID,
        packageName: _selectedPackage!.packageName,
        appointmentDate: appointmentDate,
        appointmentTime: appointmentTime,
        appointmentType: _appointmentType,
        notes: _notesController.text.trim().isEmpty ? null : _notesController.text.trim(),
        totalPrice: _calculatedPrice,
        estimatedDuration: _estimatedMinutes,
      );

      if (appointmentID != null && mounted) {
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Appointment created successfully! Vehicle: $_selectedBrand $_selectedModel'), backgroundColor: const Color(0xFF4CAF50), duration: const Duration(seconds: 3)),
        );
        
        final managerProvider = context.read<ManagerProvider>();
        await managerProvider.fetchAppointments(widget.branchID);
      }
    } catch (e) {
      setState(() => _isSaving = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Failed to create appointment: $e'), backgroundColor: Colors.red, duration: const Duration(seconds: 5)));
      }
    }
  }
}