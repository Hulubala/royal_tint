import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:royal_tint/data/models/appointment_model.dart';

/// Service for managing appointments in Firebase
class AppointmentService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  /// Create a new appointment
  Future<String?> createAppointment({
    required String customerName,
    required String customerPhone,
    required String branchID,
    required String vehicleBrand,
    required String vehicleModel,
    required String vehicleType,
    required String vehiclePlate,
    required String packageID,
    required String packageName,
    required String appointmentDate,
    required String appointmentTime,
    required String appointmentType, // 'scheduled' or 'walk-in'
    String? notes,
    required double totalPrice,
    required int estimatedDuration, // in minutes
  }) async {
    try {
      // Create vehicle info map
      final vehicleInfo = {
        'brand': vehicleBrand,
        'model': vehicleModel,
        'type': vehicleType,
        'plateNumber': vehiclePlate,
      };

      // Create appointment data
      final appointmentData = {
        'customerID': 'GUEST_${DateTime.now().millisecondsSinceEpoch}', // Generate temporary customer ID
        'customerName': customerName,
        'customerPhone': customerPhone,
        'branchID': branchID,
        'vehicleInfo': vehicleInfo,
        'packageID': packageID,
        'packageName': packageName,
        'appointmentDate': appointmentDate,
        'appointmentTime': appointmentTime,
        'appointmentType': appointmentType,
        'estimatedDuration': estimatedDuration, // Store duration
        'status': 'pending', // New appointments start as pending
        'assignedStaffID': null,
        'notes': notes,
        'totalPrice': totalPrice,
        'createdAt': FieldValue.serverTimestamp(),
        'updatedAt': FieldValue.serverTimestamp(),
      };

      // Add to Firestore
      final docRef = await _firestore.collection('appointments').add(appointmentData);
      
      print('✅ Appointment created successfully with ID: ${docRef.id}');
      return docRef.id;
    } catch (e) {
      print('❌ Error creating appointment: $e');
      rethrow;
    }
  }

  /// Update appointment status
  Future<void> updateAppointmentStatus({
    required String appointmentID,
    required String newStatus,
  }) async {
    try {
      await _firestore.collection('appointments').doc(appointmentID).update({
        'status': newStatus.toLowerCase(),
        'updatedAt': FieldValue.serverTimestamp(),
      });
      print('✅ Appointment status updated to $newStatus');
    } catch (e) {
      print('❌ Error updating appointment status: $e');
      rethrow;
    }
  }

  /// Delete appointment
  Future<void> deleteAppointment(String appointmentID) async {
    try {
      await _firestore.collection('appointments').doc(appointmentID).delete();
      print('✅ Appointment deleted successfully');
    } catch (e) {
      print('❌ Error deleting appointment: $e');
      rethrow;
    }
  }

  /// Get all appointments for a branch
  Stream<List<AppointmentModel>> getAppointmentsStream(String branchID) {
    return _firestore
        .collection('appointments')
        .where('branchID', isEqualTo: branchID)
        .orderBy('appointmentDate', descending: false)
        .orderBy('appointmentTime', descending: false)
        .snapshots()
        .map((snapshot) => snapshot.docs
            .map((doc) => AppointmentModel.fromFirestore(doc))
            .toList());
  }

  /// Get appointments for a specific date
  Future<List<AppointmentModel>> getAppointmentsByDate({
    required String branchID,
    required String date,
  }) async {
    try {
      final querySnapshot = await _firestore
          .collection('appointments')
          .where('branchID', isEqualTo: branchID)
          .where('appointmentDate', isEqualTo: date)
          .orderBy('appointmentTime')
          .get();

      return querySnapshot.docs
          .map((doc) => AppointmentModel.fromFirestore(doc))
          .toList();
    } catch (e) {
      print('❌ Error fetching appointments by date: $e');
      return [];
    }
  }

  /// Check if a time slot is available
  Future<bool> isTimeSlotAvailable({
    required String branchID,
    required String date,
    required String time,
    String? excludeAppointmentID,
  }) async {
    try {
      var query = _firestore
          .collection('appointments')
          .where('branchID', isEqualTo: branchID)
          .where('appointmentDate', isEqualTo: date)
          .where('appointmentTime', isEqualTo: time)
          .where('status', whereIn: ['pending', 'confirmed']); // Only check active appointments

      final querySnapshot = await query.get();

      // If excluding an appointment (for updates), filter it out
      if (excludeAppointmentID != null) {
        return querySnapshot.docs
            .where((doc) => doc.id != excludeAppointmentID)
            .isEmpty;
      }

      return querySnapshot.docs.isEmpty;
    } catch (e) {
      print('❌ Error checking time slot availability: $e');
      return false;
    }
  }
}